<?php


$xml = simplexml_load_file('kulture.xml');

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Početna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="stilizirano.css">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">KULTURE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Početna</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Kategorije
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="Stranice/Poljuprivreda.php">Poljuprivreda</a></li>
            <li><a class="dropdown-item" href="Stranice/Vino.php">Vino</a></li>
            <li><a class="dropdown-item" href="Stranice/Ulje.php">Ulje</a></li>
            <li><a class="dropdown-item" href="Stranice/Stocarstvo.php">Stocarstvo</a></li>
            <li><a class="dropdown-item" href="Stranice/Ribarstvo.php">Ribarstvo</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="Stranice/Sve.php">Prikazi sve</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
  </nav>

		<div class="blok">
			<h2>Hrvatske kulture uzgoja</h2>
      <p>Uzgoj kultura u Hrvatskoj ima dugu tradiciju i važnu ulogu u gospodarstvu zemlje. Kroz stoljeća, Hrvatska se razvila kao plodno tlo za uzgoj raznih kultura, zahvaljujući povoljnoj klimi, plodnoj zemlji i bogatim izvorima vode.</p>
      <p>Mnogi poljoprivrednici u Hrvatskoj koji se bave uzgojem kultura organizirani su kao Obiteljska poljoprivredna gospodarstva (OPG-ovi). OPG-ovi su ključni igrači u poljoprivrednoj industriji Hrvatske i predstavljaju temelj ruralnog razvoja. Oni igraju važnu ulogu u očuvanju tradicionalnih metoda uzgoja kultura, ali također su otvoreni za uvođenje suvremenih tehnika i tehnologija kako bi poboljšali učinkovitost i kvalitetu svoje proizvodnje.</p>
      <h3>Vinova loza</h3>
      <img id="slika1" src="Slike/vinovaloza.jpg" title="Loza">
      <p>Jedna od najčešćih kultura koje se uzgajaju u Hrvatskoj je vinova loza. Vinogradarstvo ima dugu tradiciju u zemlji, a hrvatska vina poznata su i priznata diljem svijeta. OPG-ovi vinogradari brinu se o vinovoj lozi tijekom cijelog ciklusa uzgoja, od sadnje do berbe. Oni prate specifične uvjete svog područja, brinu se o tlu, obrezivanju, navodnjavanju i zaštiti od bolesti i štetnika. OPG-ovi često njeguju autohtone sorte vinove loze, čime pridonose očuvanju kulturne baštine i bogatstva sortimenta.</p> 
      <p>Uz vinovu lozu, u Hrvatskoj se uzgajaju i mnoge druge kulture poput maslina, voća, povrća, žitarica i ljekovitog bilja. OPG-ovi koji se bave uzgojem ovih kultura marljivo rade na njihovom uzgoju i brinu se o svakom detalju proizvodnje. Oni obrađuju zemlju, sade sjeme ili sadnice, pravilno gnoje i zalijevaju usjeve, te primjenjuju mjere zaštite bilja kako bi osigurali zdrave i kvalitetne proizvode.</p>
      <h3>Uzgoj stoke</h3>
      <img id="slika2" src="Slike/slikakrava.jpg" title="Kravice">
      <p>Uzgoj stoke ima važno mjesto u poljoprivredi Hrvatske i predstavlja vitalnu granu gospodarstva. Obiteljska poljoprivredna gospodarstva (OPG-ovi) često se bave uzgojem stoke kao što su goveda, svinje, ovce, koze i perad. OPG-ovi koji se brinu o stoci obavljaju različite zadatke, uključujući reprodukciju, hranjenje, zdravstvenu zaštitu i upravljanje stajskim gnojem.</p>
      <p>Uzgoj goveda je jedan od najznačajnijih segmenata stočarstva u Hrvatskoj. OPG-ovi uzgajaju goveda za meso, mlijeko ili oboje. Briga o govedima uključuje osiguravanje kvalitetne prehrane, redovito cijepljenje, veterinarsku njegu i pravilno upravljanje stajskim gnojem radi zaštite okoliša. Uzgoj goveda u Hrvatskoj često je povezan s tradicionalnim pasminama poput simentalske i podolske, ali se također primjenjuju moderne tehnologije i genetika radi poboljšanja proizvodnih performansi.</p>
      <p>OPG-ovi također igraju ključnu ulogu u promociji lokalne prehrane i održivog razvoja. Mnogi se bave organskim uzgojem, koristeći ekološki prihvatljive metode koje minimiziraju upotrebu kemikalija i štite okoliš. OPG-ovi često imaju izravan kontakt s potrošačima putem prodaje na tržnicama, kućnim dostavama ili otvaranjem vlastitih prodavaonica. To omogućuje potrošačima da dobiju svježe i visokokvalitetne proizvode, te istovremeno podrže lokalne proizvođače i zajednicu.</p>
      <p>Uzgoj kultura u Hrvatskoj zahtijeva strpljenje, predanost i znanje. OPG-ovi su nositelji tradicije i inovacije u poljoprivrednom sektoru, čime pridonose održivom razvoju ruralnih područja i bogatstvu hrvatske kulturne baštine. Njihov rad i posvećenost uzgoju kultura odražava se u izvrsnosti proizvoda koji se odlikuju okusom, kvalitetom i prepoznatljivošću na tržištu.</p>
    </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <footer>
  <div id="copyright" class="container">
	  <p>©Matej Josipović</p>
  </div>
  </footer>
    
  </body>
</html>